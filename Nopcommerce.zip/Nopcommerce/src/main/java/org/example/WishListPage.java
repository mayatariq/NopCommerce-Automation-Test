package org.example;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class WishListPage {
    private WebDriver driver;
    public  WishListPage(WebDriver driver) {
        this.driver = driver;
    }
    String wish;
    public void AddWishList(){
       // driver.findElement(By.xpath("(//a[@href='/books'])[2]")).click();
        driver.findElement(By.id("small-searchterms")).sendKeys("Camera", Keys.ENTER);

        wish = driver.findElement(By.xpath("//a[text()='Leica T Mirrorless Digital Camera']")).getText();

        // Open product page


//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-wishlist-button-45"))).click();

        //driver.findElement(By.id("add-to-wishlist-button-45")).click();
        driver.findElement(By.xpath("//button[@class='button-2 add-to-wishlist-button']")).click();
    }
    public void checkWishList(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement wishlistBtn = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='wishlist-label']"))
        );

        // Scroll UP to the button to make sure it's visible
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", wishlistBtn);

        // Click the wishlist button
        wishlistBtn.click();
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='wishlist-label']")));
        //driver.findElement(By.xpath("//span[@class='wishlist-label']")).click();

         wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='product-name']")));

        Assert.assertEquals(
                driver.findElement(By.xpath("//a[@class='product-name']")).getText(),
                wish
        );
    }
}
