package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class SearchPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public SearchPage(WebDriver driver) {
        this.driver = driver;

    }

    String Laptop1;
    String Laptop2;

    public void Search() {
        //driver.get("https://demo.nopcommerce.com/");
       // wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("topic-block-title")));
       // Assert.assertEquals(driver.findElement(By.className("topic-block-title")).getText(), "Welcome to our store");
       // driver.findElement(By.id("small-searchterms")).sendKeys("Laptop", Keys.ENTER);

//        AddComparePage addComparePage = new AddComparePage(driver);
//        addComparePage.addcompare();
        driver.findElement(By.id("small-searchterms")).sendKeys("iphone 16", Keys.ENTER);
        //wait.until(ExpectedConditions.textToBePresentInElementLocated(By.className("page-title"), "Search"));
        Assert.assertEquals(driver.findElement(By.className("page-title")).getText(), "Search");

    }



    public String getLaptop1() {
        return Laptop1;
    }

    public String getLaptop2() {
        return Laptop2;
    }

}
