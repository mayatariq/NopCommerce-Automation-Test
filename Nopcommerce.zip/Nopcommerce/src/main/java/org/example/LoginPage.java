package org.example;

import net.bytebuddy.asm.Advice;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class LoginPage {
    private WebDriver driver;
    public LoginPage(WebDriver driver) {
        this.driver = driver;

    }

    public void login(String email, String password) {
       // driver.findElement(By.className("ico-logout")).click();
        driver.findElement(By.className("ico-login")).click();
      //  Assert.assertEquals(driver.findElement(By.xpath("//div[@class='page login-page']")).getText(), "Welcome, Please Sign In!");
        driver.findElement(By.xpath("//input[@class='email']")).sendKeys(email);
        driver.findElement(By.xpath("//input[@class='password']")).sendKeys(password, Keys.ENTER);
       // driver.findElements(By.xpath("//img[@alt='nopCommerce demo store']")).get(1).click();
       // Assert.assertEquals(driver.findElement(By.className("topic-block-title")).getText(), "Welcome to our store");

    }


}
