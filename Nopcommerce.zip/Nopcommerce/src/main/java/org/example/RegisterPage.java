package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;



public class RegisterPage {
    private WebDriver driver;

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    private final By FirstName = By.id("FirstName");
    private final By LastName = By.id("LastName");
    private final By Email = By.id("Email");
    private final By Company = By.id("Company");
    private final By Password = By.id("Password");
    private final By ConfirmPassword = By.id("ConfirmPassword");

    private final By errorMessage1=By.id("FirstName-error");
    private final By errorMessage2=By.id("LastName-error");
    private final By errorMessage3=By.id("Email-error");
    private final By errorMessage4=By.id("Password-error");
    private final By errorMessage5=By.id("ConfirmPassword-error");

    private final By successMessage=By.xpath("//div[@class='result']");
    private final By continueButton = By.xpath("//a[@class='button-1 register-continue-button']");

    public void enterRegisterCredentials(String first, String last, String email, String company, String password, String confirmPassword) {
        driver.findElement(FirstName).clear();
        driver.findElement(LastName).clear();
        driver.findElement(Email).clear();
        driver.findElement(Company).clear();
        driver.findElement(Password).clear();
        driver.findElement(ConfirmPassword).clear();
        driver.findElement(FirstName).sendKeys(first);
        driver.findElement(LastName).sendKeys(last);
        driver.findElement(Email).sendKeys(email);
        driver.findElement(Company).sendKeys(company);
        driver.findElement(Password).sendKeys(password);
        driver.findElement(ConfirmPassword).sendKeys(confirmPassword, Keys.ENTER);

    }


    public void errorDisplayed() {
        boolean errorVisible = false;

        try { errorVisible |= driver.findElement(errorMessage1).isDisplayed(); } catch (NoSuchElementException ignored) {}
        try { errorVisible |= driver.findElement(errorMessage2).isDisplayed(); } catch (NoSuchElementException ignored) {}
        try { errorVisible |= driver.findElement(errorMessage3).isDisplayed(); } catch (NoSuchElementException ignored) {}
        try { errorVisible |= driver.findElement(errorMessage4).isDisplayed(); } catch (NoSuchElementException ignored) {}
        try { errorVisible |= driver.findElement(errorMessage5).isDisplayed(); } catch (NoSuchElementException ignored) {}

        Assert.assertTrue(errorVisible, "No validation error message was displayed!");
    }

    public void registeredSuccessfully() {
        // Get the actual message text
        String actualMessage = driver.findElement(successMessage).getText();
        String expectedMessage = "Your registration completed";

        // Assert that the message matches exactly
        Assert.assertEquals(actualMessage, expectedMessage, "Success message did not match!");

        // Click the continue button
        driver.findElement(continueButton).click();
        driver.findElements(By.xpath("//img[@alt='nopCommerce demo store']")).get(1).click();
    }


}
