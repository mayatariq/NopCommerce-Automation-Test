package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;


public class CartPage {
    //product-item
    private WebDriver driver;
    private WebDriverWait wait;

    public CartPage(WebDriver driver) {
        this.driver = driver;

    }

    public void  addCart() {
        driver.findElement(By.xpath("//div[@class='product-item']")).isDisplayed();
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='product-item']")));
        driver.findElement(By.xpath("//div[@class='product-item']")).click();
        driver.findElement(By.xpath("//button[@id='add-to-cart-button-21']")).click();
    }
    public void validateCart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='cart-label']")));
      driver.findElement(By.xpath("//span[@class='cart-label']")).click();
      String Home = driver.findElement(By.className("product-name")).getText();
      String cart = driver.findElement(By.className("product-name")).getText();
      Assert.assertEquals(Home, cart);
    }

//public void validateCart() {
//    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//    // Wait until product name is visible in cart
//    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='product-name']")));
//
//    String home = driver.findElement(By.xpath("//div[@class='product-name']")).getText();
//    String cart = driver.findElement(By.xpath("//a[@class='product-name']")).getText();
//
//    Assert.assertEquals(cart, home, " Product in cart does not match product page");
//}

}
