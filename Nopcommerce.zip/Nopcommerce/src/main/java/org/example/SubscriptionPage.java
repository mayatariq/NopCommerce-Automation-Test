package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class SubscriptionPage {
    private WebDriver driver;
    public SubscriptionPage(WebDriver driver) {
        this.driver = driver;

    }
    public void Subscripe(){
        driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']")).click();
        driver.findElement(By.id("newsletter-email")).sendKeys("Maya@gmail.com");
        driver.findElement(By.id("newsletter-subscribe-button")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("newsletter-result-block")));

        Assert.assertTrue(driver.findElement(By.xpath("//div[@id='newsletter-result-block']")).isDisplayed());
        //Assert.assertEquals(driver.findElement(By.className("newsletter-result")).getText(),"Thank you for signing up! A verification email has been sent. We appreciate your interest.");


    }
}
