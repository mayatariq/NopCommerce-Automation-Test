package org.example;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.Map;

public class CheckFormPage {

    private WebDriver driver;

    // Locators for checkout form
    private By firstNameField = By.id("BillingNewAddress_FirstName");
    private By lastNameField = By.id("BillingNewAddress_LastName");
    private By emailField = By.id("BillingNewAddress_Email");
    private By companyField = By.id("BillingNewAddress_Company");
    private By countryDropdown = By.id("BillingNewAddress_CountryId");
    private By stateDropdown = By.id("BillingNewAddress_StateProvinceId");
    private By cityField = By.id("BillingNewAddress_City");
    private By address1Field = By.id("BillingNewAddress_Address1");
    private By postalCodeField = By.id("BillingNewAddress_ZipPostalCode");
    private By phoneNumberField = By.id("BillingNewAddress_PhoneNumber");
    private By faxNumberField = By.id("BillingNewAddress_FaxNumber");

    private By continueButton = By.xpath("//button[@name='save']");

    public CheckFormPage(WebDriver driver) {
        this.driver = driver;
    }


    // Method to fill checkout form using JSON map
    public void fillCheckoutForm(Map<String, String> data) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.navigate().refresh();


        if (!driver.findElements(By.id("edit-billing-address-button")).isEmpty()) {
            driver.findElement(By.id("edit-billing-address-button")).click();
        }

        wait.until(ExpectedConditions.elementToBeClickable(firstNameField));
        driver.findElement(firstNameField).clear();
        driver.findElement(firstNameField).sendKeys(data.get("FirstName"));

        wait.until(ExpectedConditions.elementToBeClickable(lastNameField));
        driver.findElement(lastNameField).clear();
        driver.findElement(lastNameField).sendKeys(data.get("LastName"));

        wait.until(ExpectedConditions.elementToBeClickable(emailField));
        driver.findElement(emailField).clear();
        driver.findElement(emailField).sendKeys(data.get("Email"));

        wait.until(ExpectedConditions.elementToBeClickable(companyField));
        driver.findElement(companyField).clear();
        driver.findElement(companyField).sendKeys(data.get("Company"));

        wait.until(ExpectedConditions.elementToBeClickable(stateDropdown));
       // driver.findElement(countryDropdown).sendKeys(data.get("Country"));
        driver.findElement(stateDropdown).sendKeys(data.get("State"));

        wait.until(ExpectedConditions.elementToBeClickable(cityField));
        //driver.findElement(cityField).clear();
        driver.findElement(cityField).sendKeys(data.get("City"));

        wait.until(ExpectedConditions.elementToBeClickable(address1Field));
       // driver.findElement(address1Field).clear();
        driver.findElement(address1Field).sendKeys(data.get("Address1"));

        wait.until(ExpectedConditions.elementToBeClickable(postalCodeField));
        //driver.findElement(postalCodeField).clear();
        driver.findElement(postalCodeField).sendKeys(data.get("PostalCode"));

        wait.until(ExpectedConditions.elementToBeClickable(phoneNumberField));
       // driver.findElement(phoneNumberField).clear();
        driver.findElement(phoneNumberField).sendKeys(data.get("PhoneNumber"));

        wait.until(ExpectedConditions.elementToBeClickable(faxNumberField));
       // driver.findElement(faxNumberField).clear();
        driver.findElement(faxNumberField).sendKeys(data.get("FaxNumber"));
    }


    public void submitCheckoutForm() {
        driver.findElement(By.xpath("//button[@class='button-1 new-address-next-step-button']")).click();

    }
    SoftAssert softAssert = new SoftAssert();
    public void continueButtonClick() {
       String check = driver.findElement(By.xpath("//div[@class='page-title']")).getText();



        softAssert.assertEquals(
                driver.findElement(By.xpath("//div[@class='page-title']")).getText(),
                check
        );
       // Assert.assertEquals(driver.findElement(By.xpath("//div[@class='page-title']")).getText(), check);
        driver.findElement(By.xpath("//button[@class='button-1 shipping-method-next-step-button']")).click();

    }
    public void finishCheckoutForm() {
        driver.findElement(By.id("checkout-step-shipping-method")).click();
        driver.findElement(By.xpath("//button[@class='button-1 payment-info-next-step-button']")).click();
        driver.findElement(By.xpath("//button[@class='button-1 confirm-order-next-step-button']")).click();

        softAssert.assertEquals(
                driver.findElement(By.xpath("//div[@class='page-title']")).getText(),
                "Thank you"
        );
       // Assert.assertEquals(driver.findElement(By.xpath("//div[@class='page-title']")).getText(), "Thank you");
    }

}
