package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class AddComparePage {
    private WebDriver driver;

    public AddComparePage(WebDriver driver) {
        this.driver = driver;
    }
    String lap1;
    String lap2;

//    public void addcompare(){
//        driver.findElement(By.id("small-searchterms")).sendKeys("Laptop", Keys.ENTER);
//         lap1 = driver.findElement(By.xpath("//a[text()='Asus Laptop']")).getText();
//         lap2 = driver.findElement(By.xpath("//a[text()='Lenovo Thinkpad Carbon Laptop']")).getText();
//
////        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
////
////
////        driver.findElement(By.xpath("//button[@class='button-2 add-to-compare-list-button']")).click();
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        driver.findElement(By.xpath("(//button[@class='button-2 add-to-compare-list-button'])[1]")).click();
//        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".bar-notification.success")));
//
////        driver.findElement(By.xpath("//img[@alt='Picture of Lenovo Thinkpad Carbon Laptop']")).click();
////        driver.findElement(By.xpath("(//button[@class='button-2 add-to-compare-list-button'])[1]")).click();
//
//       // driver.findElement(By.xpath("//img[@alt='Picture of Lenovo Thinkpad Carbon Laptop']")).click();
//        driver.findElement(By.xpath("(//button[@class='button-2 add-to-compare-list-button'])[2]")).click();
//        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".bar-notification.success")));
//    }
public void addcompare() {
    driver.findElement(By.id("small-searchterms")).sendKeys("Laptop", Keys.ENTER);

    lap1 = driver.findElement(By.xpath("//a[text()='Asus Laptop']")).getText();
    lap2 = driver.findElement(By.xpath("//a[text()='Lenovo Thinkpad Carbon Laptop']")).getText();

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    // Add first product
    driver.findElement(By.xpath("(//button[@class='button-2 add-to-compare-list-button'])[1]")).click();
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".bar-notification.success")));
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".bar-notification.success")));

    // Add second product
    driver.findElement(By.xpath("(//button[@class='button-2 add-to-compare-list-button'])[2]")).click();
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".bar-notification.success")));
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".bar-notification.success")));
}



    public void comparison() {
        driver.findElement(By.xpath("//a[text()='Compare products list']")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Lenovo Thinkpad Carbon Laptop']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Asus Laptop']")));

        Assert.assertEquals(driver.findElement(By.xpath("//a[text()='Lenovo Thinkpad Carbon Laptop']")).getText(), lap2);
        Assert.assertEquals(driver.findElement(By.xpath("//a[text()='Asus Laptop']")).getText(), lap1);
    }



//    public void comparison(){
//        driver.findElement(By.xpath("//a[text()='Compare products list']")).click();
//
//
//        Assert.assertEquals(driver.findElement(By.xpath("//a[contains(text(),'Lenovo Thinkpad')]")).getText(), lap2);
//
//
//        Assert.assertEquals(driver.findElement(By.xpath("//a[text()='Asus Laptop']")).getText(), lap1);
//
//    }
}
