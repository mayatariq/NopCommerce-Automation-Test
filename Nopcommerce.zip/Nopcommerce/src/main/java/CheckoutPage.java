import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class CheckoutPage {
    //checkout
    private WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

   public void checkout(){
        driver.findElements(By.id("termsofservice")).get(0).click();
       driver.findElements(By.id("checkout")).get(0).click();
       

   }
}
