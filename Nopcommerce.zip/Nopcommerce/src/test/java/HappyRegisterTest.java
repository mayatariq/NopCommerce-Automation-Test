import org.testng.annotations.Test;
import org.example.RegisterPage;

public class HappyRegisterTest extends BaseTest {
@Test(dataProvider = "Credentials")
    public void testRegister(String firstName, String lastName, String email, String companies, String password, String confirmPassword)  {

    RegisterPage registerPage = new RegisterPage(driver);
    registerPage.enterRegisterCredentials(firstName,lastName,email,companies,password,confirmPassword);
    //registerPage.registeredSuccessfully();
}
}
