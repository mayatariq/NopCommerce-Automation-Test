import org.example.CheckFormPage;
import org.testng.annotations.Test;

import java.util.Map;


public class CheckFormTest extends  BaseTest{
    @Test(dataProvider = "negativeCheckoutData")
    public void CheckForm(Map<String, String> data) {
        CheckFormPage checkFormPage = new CheckFormPage(driver);


        checkFormPage.fillCheckoutForm(data);


        checkFormPage.submitCheckoutForm();
        checkFormPage.continueButtonClick();
        checkFormPage.finishCheckoutForm();

        // Assert messages/errors here (depending on positive or negative case)
    }
}
