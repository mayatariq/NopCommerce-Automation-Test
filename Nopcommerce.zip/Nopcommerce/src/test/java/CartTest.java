import org.example.CartPage;
import org.testng.annotations.Test;

public class CartTest extends BaseTest {
    @Test
    public void checkCart() {
        CartPage cartPage = new CartPage(driver);
        cartPage.addCart();
        cartPage.validateCart();
    }
}
