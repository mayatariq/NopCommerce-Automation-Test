package util;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class CSVUtils {
    public static List<String> getSpecificColumnData(String filePath, String columnName) {
        List<String> columnData = new ArrayList<>();
        try (FileReader reader = new FileReader(filePath)) {
            Iterable<CSVRecord> records = CSVFormat.DEFAULT
                    .withFirstRecordAsHeader()
                    .parse(reader);

            for (CSVRecord record : records) {
                columnData.add(record.get(columnName));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return columnData;
    }
}
