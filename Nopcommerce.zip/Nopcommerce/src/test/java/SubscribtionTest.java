import org.example.SubscriptionPage;
import org.testng.annotations.Test;

public class SubscribtionTest extends BaseTest{
    @Test
    public void SubscribtionTest()
    {
        SubscriptionPage subscriptionPage = new SubscriptionPage(driver);
        subscriptionPage.Subscripe();
    }
}
