import org.example.AddComparePage;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class CompareTest extends BaseTest{

    @Test
    public void compareTest(){
        AddComparePage addComparePage = new AddComparePage(driver);
        addComparePage.addcompare();


//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Compare products list']")));
        addComparePage.comparison();
    }
}
