import org.example.RegisterPage;
import org.testng.annotations.Test;
import util.CSVUtils;


import java.util.List;
public class RegisterTest extends BaseTest {
    @Test
    public void RegisterTest() {
        //String filePath = getClass().getClassLoader().getResource("NegativeReg.csv").getPath();

        String filePath = "src/main/resources/NegativeRegister.csv";
        RegisterPage registerPage = new RegisterPage(driver);
        // read each column
        List<String> firstNames = CSVUtils.getSpecificColumnData(filePath, "FirstName");
        List<String> lastNames = CSVUtils.getSpecificColumnData(filePath, "LastName");
        List<String> emails = CSVUtils.getSpecificColumnData(filePath, "Email");
        List<String> companies = CSVUtils.getSpecificColumnData(filePath, "Company");
        List<String> passwords = CSVUtils.getSpecificColumnData(filePath, "Password");
        List<String> confirmPasswords = CSVUtils.getSpecificColumnData(filePath, "Confirm Pass");

        // loop over rows
        for (int i = 0; i < firstNames.size(); i++) {

            registerPage.enterRegisterCredentials(
                    firstNames.get(i),
                    lastNames.get(i),
                    emails.get(i),
                    companies.get(i),
                    passwords.get(i),
                    confirmPasswords.get(i)

            );

            registerPage.errorDisplayed();


        }



    }


}
