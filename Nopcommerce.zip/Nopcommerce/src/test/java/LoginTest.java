import org.example.LoginPage;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test(dataProvider = "LoginCredentials")
    public void LoginTest(String email, String password){
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(email, password);
    }

}
