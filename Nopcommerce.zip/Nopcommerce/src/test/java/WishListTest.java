import org.example.WishListPage;
import org.testng.annotations.Test;

public class WishListTest extends BaseTest{
    @Test
    public void checkWishList(){
        WishListPage wishListPage = new WishListPage(driver);
        wishListPage.AddWishList();
        wishListPage.checkWishList();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
