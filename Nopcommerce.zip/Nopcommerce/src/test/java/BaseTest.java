import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import util.JsonFileManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class BaseTest {
    public static WebDriver driver;

    @BeforeSuite
    public void setUp() {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--incognito");
        driver = new ChromeDriver(chromeOptions);
        driver.manage().window().maximize();
        driver.get("https://demo.nopcommerce.com/register");
    }

    @DataProvider(name = "Credentials")
    public Object[][] getData(){
        return new Object[][]{{"Maya","Tariq","Maya@gmail.com","NTI","12345678","12345678"}};
    }

    @DataProvider(name = "LoginCredentials")
    public Object[][] getLoginData(){
        return new Object[][]{{"Maya@gmail.com","12345678"}};
    }

    public void takeScreenshot(String name) {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File srcFile = ts.getScreenshotAs(OutputType.FILE);

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File screenshotsDir = new File("screenshots");
        if (!screenshotsDir.exists()) {
            screenshotsDir.mkdirs();
        }

        File destFile = new File("screenshots/" + name + "_" + timestamp + ".png");
        try {
            FileHandler.copy(srcFile, destFile);
            System.out.println("📸 Screenshot saved: " + destFile.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @DataProvider(name = "negativeCheckoutData")
    public Object[][] negativeCheckoutData() {
        JsonFileManager jsonFileManager = new JsonFileManager("src/test/resources/NegativeCheckout.json");
        return jsonFileManager.getObjectData();
    }

    @AfterMethod
    public void captureScreenshotOnFailure(ITestResult result) {


        if (ITestResult.FAILURE == result.getStatus()) {

            TakesScreenshot ts = (TakesScreenshot) driver;

            File srcFile = ts.getScreenshotAs(OutputType.FILE);

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

            File screenshotsDir = new File("screenshots");

            if (!screenshotsDir.exists()) {
                screenshotsDir.mkdirs();
            }

            String fileName = "screenshots/" + result.getName() + "_" + timestamp + ".png";
            File destFile = new File(fileName);

            try {
                FileHandler.copy(srcFile, destFile);
                System.out.println("Screenshot saved: " + destFile.getAbsolutePath());

            } catch (IOException e) {
                e.printStackTrace();

            }
        }
    }


    @AfterSuite
    public void tearDown() {}
}
