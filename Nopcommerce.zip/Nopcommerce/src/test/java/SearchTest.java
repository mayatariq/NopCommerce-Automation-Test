import org.example.SearchPage;
import org.testng.annotations.Test;

public class SearchTest extends BaseTest{
    @Test
    public void SearchTest() {

        SearchPage searchPage = new SearchPage(driver);
        searchPage.Search();

    }
}
