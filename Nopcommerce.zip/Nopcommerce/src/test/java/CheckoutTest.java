import org.testng.annotations.Test;

public class CheckoutTest extends BaseTest{
    @Test
    public void checkout(){

        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.checkout();
    }
}
